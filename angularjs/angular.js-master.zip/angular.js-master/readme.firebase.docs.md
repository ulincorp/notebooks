Firebase for docs.angularjs.org
===============================

The docs are deployed to Google Firebase hosting via Travis deployment config, which expects
firebase.json and .firebaserc in the repository root.

See travis.yml for the complete deployment config.

See /scripts/code.angularjs.org-firebase/readme.firebase.code.md for the firebase deployment to
code.angularjs.org